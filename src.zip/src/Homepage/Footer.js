import React from 'react'
import "./Footer.css"
import footer from "../Asset/footer.png"
const Footer = () => {
  return (
    <div className='Footer-Container'>
     <img src={footer}/>  
               
    </div>
  )
}

export default Footer